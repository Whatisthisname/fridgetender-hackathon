async function onClickIngredientButton() {
        
        let fridge = document.getElementById("fridge")
        // console.log(fridge)
        let input = ""
        var children = fridge.children;
        // console.log(children[0])
        // console.log(children[1])
        // console.log(children[2])
        for (var i = 0; i < children.length; i++) {
            // console.log(children[i].getAttribute("class"))
            
            if (children[i].getAttribute("class") === "fridge_row") {
                // console.log(children[i])
                if (children[i].value != "") {
                    input += children[i].value + ","
                }
                // console.log(input)
            }
        }
        input = input.slice(0, -1)
//     input = document.getElementById("recipe_input").value


    function getJSON () {
        return fetch('http://3.127.80.12/get_recipe?ingredients='+input)
        .then((response) => response.json())
    }

    let text = await getJSON()

    document.getElementById("recipe_image").src = "data:image/png;base64,"+text.image_binary
    document.getElementById("recipe_output").textContent = text.recipe
}