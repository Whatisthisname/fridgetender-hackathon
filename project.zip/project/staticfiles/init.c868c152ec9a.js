const fridge = document.getElementById("fridge_pic");
const fridge_door = document.getElementById("fridge_door");
let open = false


fridge_door.addEventListener("click", function () {
    console.log("toggle fridge door");
    // change visibility of fridge
    let fridge_group = document.getElementById("fridge")
        let input = ""
        var children = fridge_group.children;

    if (open) {

        fridge.setAttribute("src", "./static/fridge_closed.png")
        for (var i = 0; i < children.length; i++) {
            if (children[i].getAttribute("class") === "fridge_row") {
                children[i].style.visibility = "hidden"
            }
        }
        fridge_door.textContent = "Open Fridge";

        open = false
        
    } else {
        
        fridge.setAttribute("src", "./static/fridge_open.png")
        for (var i = 0; i < children.length; i++) {
            if (children[i].getAttribute("class") === "fridge_row") {
                children[i].style.visibility = "visible"
            }
        }
        
        fridge_door.textContent = "Close Fridge";
        open = true
    }
});