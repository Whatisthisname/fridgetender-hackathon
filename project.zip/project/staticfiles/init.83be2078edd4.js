const fridge = document.getElementById("fridge_pic");
const fridge_door = document.getElementById("fridge_door");
let open = false


fridge_door.addEventListener("click", function () {
    console.log("toggle fridge door");
    // change visibility of fridge
    let fridge_groups = [document.getElementById("fridge_row").children[0], document.getElementById("fridge_row").children[1]]
    console.log(fridge_groups)
    var children1 = fridge_groups[0].children;
    var children2 = fridge_groups[1].children;

    if (open) {
        
        fridge.setAttribute("src", "./static/fridge_closed.png")
        for (var i = 0; i < children1.length; i++) {
            if (children1[i].getAttribute("class") === "fridge_shelf") {
                children1[i].style.visibility = "hidden"
                children2[i].style.visibility = "hidden"

                localStorage.setItem(children1[i].getAttribute("name"), children1[i].value)
                localStorage.setItem(children2[i].getAttribute("name"), children2[i].value)
            }
        }
        fridge_door.textContent = "Open Fridge";

        open = false
        
    } else {
        
        console.log("loading content")
        fridge.setAttribute("src", "./static/fridge_open.png")
        for (var i = 0; i < children1.length; i++) {
            if (children1[i].getAttribute("class") === "fridge_shelf") {
                children1[i].style.visibility = "visible"
                children2[i].style.visibility = "visible"
                
                // console.log(localStorage.getItem(children1[i].getAttribute("name")))

                children1[i].value = localStorage.getItem(children1[i].getAttribute("name"))
                children2[i].value = localStorage.getItem(children2[i].getAttribute("name"))
            }
        }
        
        fridge_door.textContent = "Close Fridge";
        open = true
    }
});