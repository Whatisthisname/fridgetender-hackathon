async function onClickIngredientButton() {

    let fridge = document.getElementById("fridge_row")
    let fridgeColumns = [fridge.children[0], fridge.children[1]]
    var children1 = fridgeColumns[0].children;
    var children2 = fridgeColumns[1].children;
    let input = ""

    // console.log(fridgeColumns)
    // console.log(children1)

    for (var i = 0; i < children1.length; i++) {
        if (children1[i].getAttribute("class") === "fridge_shelf") {
            if (children1[i].value != "") {
                input += children1[i].value + ","
            }
            if (children2[i].value != "") {
                input += children2[i].value + ","
            }
        }
    }

    console.log("found " + input)

    input = input.slice(0, -1)
    //     input = document.getElementById("recipe_input").value


    function getJSON() {
        return fetch('http://3.127.80.12/get_recipe?ingredients=' + input)
            .then((response) => response.json())
    }

    let text = await getJSON()

    document.getElementById("recipe_image").src = "data:image/png;base64," + text.image_binary
    document.getElementById("recipe_output").textContent = text.recipe
}