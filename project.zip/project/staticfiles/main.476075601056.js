async function onClickIngredientButtonORIGINAL() {
    
    input = document.getElementById("recipe_input").value


    function getJSON () {
        return fetch('http://3.127.80.12/get_recipe?ingredients='+input)
        .then((response) => response.json())
    }

    let text = await getJSON()

    document.getElementById("recipe_output").textContent = text.recipe
}

async function onClickIngredientButton() {
    
    input = document.getElementById("recipe_input").value


    function getJSON () {
        return fetch('http://3.127.80.12/get_recipe?ingredients='+input)
        .then((response) => response.json())
    }

    let text = await getJSON()

    document.getElementById("recipe_image").src = "data:image/png;base64,"+text.image_binary
    document.getElementById("recipe_output").textContent = text.recipe
}