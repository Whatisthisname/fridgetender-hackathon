async function onClickIngredientButton() {
        
        let fridge = document.getElementById("fridge")
        let input = ""
        var children = fridge.children;
        for (var i = 0; i < children.length; i++) {
            if (children[i].getAttribute("class") === "fridge_row") {
                if (children[i].value != "") {
                    input += children[i].value + ","
                }
            }
        }
        input = input.slice(0, -1)
//     input = document.getElementById("recipe_input").value


    function getJSON () {
        return fetch('http://3.127.80.12/get_recipe?ingredients='+input)
        .then((response) => response.json())
    }

    let text = await getJSON()

    document.getElementById("recipe_image").src = "data:image/png;base64,"+text.image_binary
    document.getElementById("recipe_output").textContent = text.recipe
}