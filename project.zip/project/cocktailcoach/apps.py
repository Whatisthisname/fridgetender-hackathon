from django.apps import AppConfig


class CocktailcoachConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cocktailcoach'
