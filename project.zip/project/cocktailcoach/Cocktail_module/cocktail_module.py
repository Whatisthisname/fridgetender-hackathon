from enum import Enum
import re
from typing import List
from random import choice
from random import shuffle
import pandas as pd


class i_type(Enum):
    base = 1
    modifier = 2
    garnish = 3

class i_flavor(Enum):
    alcoholic = 1
    bitter = 2
    sour = 3
    sweet = 4
    inedible = 5

class Cocktail():
    def __init__(self, recipe: str, ingredients: List["Ingredient"], name: str = 'shitty cocktail' ):
        self.name = name
        self.recipe = recipe
        self.ingredients = ingredients
    
    def __repr__(self) -> str:
        return f"{self.name}\nIngredients; {self.ingredients}\nRecipe:\n{self.recipe}"

class Ingredient():
    def __init__(self, name: str, type: i_type, flavor: i_flavor, alc_strength: int = 0):
        self.name = name
        self.type = type
        self.alc_strength = alc_strength
        self.flavor = flavor
    
    @staticmethod
    def parse_sting(input):
        names = [x.strip().lower() for x in input.split(",")]
        database = pd.read_csv('database.csv',header=0)
        ingredients_objects = []
        for i,row in database.iterrows():
            if row['Name'] in names:
                ing = Ingredient(row['Name'],row['Type'], row['Flavor'])
                ingredients_objects.append(ing)
        return ingredients_objects

    
    def __repr__(self) -> str:
        return self.name

class CocktailMaker():
    def __init__(self, ingredients: List[Ingredient]):
        self.ingredients = ingredients

    def sorted_ingredients(self):
        bases = [i for i in self.ingredients if i.type == i_type.base]
        modifiers = [i for i in self.ingredients if i.type == i_type.modifier]
        garnishes = [i for i in self.ingredients if i.type == i_type.garnish]

        return bases, modifiers, garnishes
    
    def try_sour(self, bs, ms, gs):
        sweeteners = [m for m in ms if m.flavor == i_flavor.sweet]
        sours = [m for m in ms if m.flavor == i_flavor.sour]

        if len(bs) == 0 or len(sweeteners) == 0 or len(sours) == 0:
            return None
        
        base = choice(bs)
        sour = choice(sours)
        sweetener = choice(sweeteners)

        recipe = f"50% {base.name}, 30% {sour.name} and 20% {sweetener.name}.\nShake over ice and strain into glass.\n"
        
        cocktail = Cocktail(recipe, [base, sour, sweetener])

        if len(gs) != 0:
            garnish = choice(gs)
            cocktail.recipe += f"Garnish with {garnish.name}.\n"
            cocktail.ingredients.append(garnish)
        
        return cocktail
    
    def try_aromatic(self, bs, ms, gs):
        bitters = [m for m in ms if m.flavor == i_flavor.bitter]
        non_bitters = [m for m in ms if m.flavor != i_flavor.bitter]
        
        if len(bs) == 0 or len(bitters) == 0 or len(non_bitters) == 0:
            return None
        
        base = choice(bs)
        bitter = choice(bitters)
        non_bitter = choice(non_bitters)

        recipe = f"80% {base.name}, 18% {non_bitter.name} and 2% {bitter.name}.\nServe chilled or on the rocks.\n"

        cocktail = Cocktail(recipe, [base, non_bitter, bitter])

        if len(gs) != 0:
            garnish = choice(gs)
            cocktail.recipe += f"Garnish with {garnish.name}.\n"
            cocktail.ingredients.append(garnish)
        
        return cocktail
    
    def try_shot(self, bs, ms, gs):
        if len(bs) == 0:
            return None
        
        base = choice(bs)

        recipe = f"Pour a shot of {base.name}.\n"
        cocktail = Cocktail(recipe, [base])

        if len(gs) != 0:
            garnish = choice(gs)
            cocktail.recipe += f"Chase with {garnish.name}.\n"

        return cocktail

    def make_cocktail(self):
        sorted_ingredients = self.sorted_ingredients()
        first_priority = [self.try_sour, self.try_aromatic]
        shuffle(first_priority)

        for p in first_priority:
            cocktail = p(*sorted_ingredients)
            if cocktail is not None:
                return cocktail
        
        return self.try_shot(*sorted_ingredients)
        


if __name__ == '__main__':
    ingredients = [
        Ingredient('tequila', i_type['base'], i_flavor['alcoholic']),
        Ingredient('campari', i_type['modifier'], i_flavor['bitter']),
        Ingredient('cointreau', i_type['modifier'], i_flavor['sweet']),
        Ingredient('lime juice', i_type['modifier'], i_flavor['sour']),
        Ingredient('lime', i_type['garnish'], i_flavor['sour'])
    ]

    my_maker = CocktailMaker(ingredients)

    cocktail = my_maker.make_cocktail()

    print(cocktail)









    
