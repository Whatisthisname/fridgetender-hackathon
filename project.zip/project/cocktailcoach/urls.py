from django.urls import path
import cocktailcoach

from . import views

urlpatterns = [
    path('', views.init),
    path('get_recipe', views.ingredients2recipe),
    # path('get_image', ),
    # path('test', cocktailcoach.create_im.create_image),
]