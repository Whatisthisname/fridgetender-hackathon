from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.template import loader
import numpy as np
import json
import io
import os
import warnings
# from PIL import Image
from stability_sdk import client
import stability_sdk.interfaces.gooseai.generation.generation_pb2 as generation
from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.template import loader
import numpy as np
import json
import django
import base64
import uuid
# from project.cocktailcoach.create_im import create_image

import os

def init(request):
    template = loader.get_template('homepage.html')
    context = {"link" : request.GET.get('link')}
    return HttpResponse(template.render(context, request))

def ingredients2recipe(request):
    ingredients = Ingredient.parse_string(request.GET.get('ingredients'))
    
    my_maker = CocktailMaker(ingredients)

    cocktail = my_maker.make_cocktail()

    if cocktail != None : #success
        image_ascii = create_image("photorealistic delicious cocktail with " + " and ".join([x.name for x in cocktail.ingredients]))
        return JsonResponse({"recipe":cocktail.recipe, "image_binary":image_ascii})
    else: # no recipe found
        image_ascii = create_image("photorealistic delicious cocktail with " + " and ".join([x.strip().lower() for x in request.GET.get('ingredients').split(",")]))
        return JsonResponse({"recipe":"Sorry! Could not find any recipe.\nMaybe you can draw some inspiration from this image?", "image_binary":image_ascii})

def test(request):
    return JsonResponse({'foo':'bar'})




def create_image(image_description):
    print(image_description)
    # return "hej"
    key2 = 'sk-sS8M3PFNDSPL2VDXjn9Hfp7rdfhy1U4jkAZnrw4bouDPb4kO'
    key1='sk-l91Rsj3jpHG0iEIhqp4kjTEkmQh69Bfxv1ibnxllEYGvAwGT'
    stability_api = client.StabilityInference(
        key=key2, 
        verbose=True,
    )
    answers = stability_api.generate(
        prompt= image_description
    )
    for resp in answers:
        for artifact in resp.artifacts:
            if artifact.finish_reason == generation.FILTER:
                warnings.warn(
                    "Your request activated the API's safety filters and could not be processed."
                    "Please modify the prompt and try again.")
            if artifact.type == generation.ARTIFACT_IMAGE:
                # image_data = artifact.binary
                return base64.b64encode(artifact.binary).decode('utf-8')

from enum import Enum
import re
from typing import List
from random import choice
from random import shuffle
from random import sample
import pandas as pd


class i_type(Enum):
    base = 1
    modifier = 2
    garnish = 3

class i_flavor(Enum):
    alcoholic = 1
    bitter = 2
    sour = 3
    sweet = 4
    inedible = 5

class Cocktail():
    def __init__(self, recipe: str, ingredients: List["Ingredient"], name: str = 'shitty cocktail' ):
        self.name = name
        self.recipe = recipe
        self.ingredients = ingredients
    
    def __repr__(self) -> str:
        return f"{self.name}\nIngredients; {self.ingredients}\nRecipe:\n{self.recipe}"

class Ingredient():
    def __init__(self, name: str, type: i_type, flavor: i_flavor, alc_strength: int = 0):
        self.name = name
        self.type = type
        self.alc_strength = alc_strength
        self.flavor = flavor
    

    @staticmethod
    def parse_string(input):
        names = list(set([x.strip().lower() for x in input.split(",")]))

        database = pd.read_csv('./staticfiles/database.csv',header=0)
        ingredients_objects = []
        for i,row in database.iterrows():
            if row['Name'] in names:
                ing = Ingredient(row['Name'], i_type[row['Type']], i_flavor[row['Flavor']])

                ingredients_objects.append(ing)
        return ingredients_objects

    
    def __repr__(self) -> str:
        return self.name

class CocktailMaker():
    def __init__(self, ingredients: List[Ingredient]):
        self.ingredients = ingredients

    def sorted_ingredients(self):
        bases = [i for i in self.ingredients if i.type == i_type.base]
        modifiers = [i for i in self.ingredients if i.type == i_type.modifier]
        garnishes = [i for i in self.ingredients if i.type == i_type.garnish]

        return bases, modifiers, garnishes
    
    def try_sour(self, bs, ms, gs):
        sweeteners = [m for m in ms if m.flavor == i_flavor.sweet]
        sours = [m for m in ms if m.flavor == i_flavor.sour]

        if len(bs) == 0 or len(sweeteners) == 0 or len(sours) == 0:
            return None
        
        base = choice(bs)
        sour = choice(sours)
        sweetener = choice(sweeteners)

        recipe = f"50% {base.name}, 30% {sour.name} and 20% {sweetener.name}.\nShake over ice and strain into glass.\n"
        
        cocktail = Cocktail(recipe, [base, sour, sweetener])

        if len(gs) != 0:
            garnish = choice(gs)
            cocktail.recipe += f"Garnish with {garnish.name}.\n"
            cocktail.ingredients.append(garnish)
        
        cocktail.recipe += "This cocktail is a sour and balances sourness and sweetness.\n"
        
        return cocktail
    
    def try_aromatic(self, bs, ms, gs):
        bitters = [m for m in ms if m.flavor == i_flavor.bitter]
        non_bitters = [m for m in ms if m.flavor != i_flavor.bitter]
        
        if len(bs) == 0 or len(bitters) == 0 or len(non_bitters) == 0:
            return None
        
        base = choice(bs)
        bitter = choice(bitters)
        non_bitter = choice(non_bitters)

        recipe = f"70% {base.name}, 25% {non_bitter.name} and 5% {bitter.name}.\nServe chilled or on the rocks.\n"

        cocktail = Cocktail(recipe, [base, non_bitter, bitter])

        if len(gs) != 0:
            garnish = choice(gs)
            cocktail.recipe += f"Garnish with {garnish.name}.\n"
            cocktail.ingredients.append(garnish)
        
        cocktail.recipe += f"This an aromatic cocktail. It is quite strong and contains some bitterness from the {bitter.name} which is complemented by the {non_bitter.name}. It is not for the faint of heart.\n"

        return cocktail
    
    def try_simple(self,bs,ms,gs):
        # ASSUMES THAT TRY SOUR HAS BEEN RUN
        sweeteners = [m for m in ms if m.flavor == i_flavor.sweet]
        sours = [m for m in ms if m.flavor == i_flavor.sour]
        if len(bs) == 0 or (len(sweeteners) == 0 and len(sours) == 0):
            return None

        base = choice(bs)
        cocktail = Cocktail(f"40% {base}", [base])
        
        
        if len(sweeteners) >= 2:
            d1, d2 = sample(sweeteners, 2)
            cocktail.recipe +=  f", 30% {d1} and 30% {d2}.\n"
            cocktail.ingredients.append(d1)
            cocktail.ingredients.append(d2)
            
        if len(sours) >= 2:
            d1, d2 = sample(sours, 2)
            cocktail.recipe +=  f", 30% {d1} and 30% {d2}.\n"
            cocktail.ingredients.append(d1)
            cocktail.ingredients.append(d2)
        
        if len(sweeteners) == 1:
            d = sweeteners[0]
            cocktail.recipe +=  f" and 60% {d}.\n"
            cocktail.ingredients.append(d)

        if len(sours) == 1:
            d = sours[0]
            cocktail.recipe +=  f" and 60% {d}.\n"
            cocktail.ingredients.append(d)

        if len(gs) != 0:
            garnish = choice(gs)
            cocktail.recipe += f"Garnish with {garnish.name}.\n"
            cocktail.ingredients.append(garnish)
        
        cocktail.recipe += "Serve with crushed ice.\n"
        cocktail.recipe += "A simple cocktail with simple ingredients. Enjoy :)\n"
        return cocktail
    
    def try_shot(self, bs, ms, gs):
        if len(bs) == 0:
            return None
        
        base = choice(bs)

        recipe = f"Pour a shot of {base.name}.\n"
        cocktail = Cocktail(recipe, [base])

        if len(gs) != 0:
            garnish = choice(gs)
            cocktail.recipe += f"Add {garnish.name}.\n"
            cocktail.ingredients.append(garnish)

        return cocktail

    def make_cocktail(self):
        sorted_ingredients = self.sorted_ingredients()
        first_priority = [self.try_sour, self.try_aromatic]
        shuffle(first_priority)

        for p in first_priority:
            cocktail = p(*sorted_ingredients)
            if cocktail is not None:
                return cocktail
        
        simple_cocktail = self.try_simple(*sorted_ingredients)
        if simple_cocktail is not None:
            return simple_cocktail

        return self.try_shot(*sorted_ingredients)