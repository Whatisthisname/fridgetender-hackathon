# import io
# import os
# import warnings
# from PIL import Image
# from stability_sdk import client
# import stability_sdk.interfaces.gooseai.generation.generation_pb2 as generation
# from django.shortcuts import render
# from django.http import HttpResponse, JsonResponse
# from django.template import loader
# import numpy as np
# import json
# import django
# import base64
# import uuid

# def create_image(image_description):
#     stability_api = client.StabilityInference(
#         key='sk-l91Rsj3jpHG0iEIhqp4kjTEkmQh69Bfxv1ibnxllEYGvAwGT', 
#         verbose=True,
#     )
#     answers = stability_api.generate(
#         prompt= image_description
#     )
#     for resp in answers:
#         for artifact in resp.artifacts:
#             if artifact.finish_reason == generation.FILTER:
#                 warnings.warn(
#                     "Your request activated the API's safety filters and could not be processed."
#                     "Please modify the prompt and try again.")
#             if artifact.type == generation.ARTIFACT_IMAGE:
#                 # image_data = artifact.binary
#                 return JsonResponse({"image_binary" : artifact.binary})
#                 # # img = Image.open(io.BytesIO(artifact.binary))
#                 # # name = uuid.uuid4()
#                 # # img.save(f"{uuid.hex}.jpg")
#                 # with open("{uuid.he}.jpg", "rb") as image_file:
#                 #     name = 
#                 #     image_data = base64.b64encode(image_file.read()).decode('utf-8')
#                 #     return HttpResponse(artifact.binary, content_type="image/jpeg")